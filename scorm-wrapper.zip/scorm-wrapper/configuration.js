ContentURL='https://cmp.nuggetkrafter.com/api/validate-and-launch?id=ID&learner_id=LEARNER_ID&name=LEARNER_FNAME&referringurl=REFERRING_URL';
